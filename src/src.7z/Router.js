import React from 'react';
import { Scene, Router, Actions } from 'react-native-router-flux';
import TvList from './components/tvShows';

const RouterComponent = () => {
    return (
        <Router sceneStyle={{ paddingTop: 5 }}>
            <Scene key="root">
                <Scene key="tvShows" component={TvList} title="TV Shows" />
            </Scene>
        </Router>
    );
};

export default RouterComponent;
