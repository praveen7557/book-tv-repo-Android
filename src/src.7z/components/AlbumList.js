import React, { Component } from 'react';
import { ScrollView } from 'react-native';
import axios from 'axios';
import AlbumDetail from './AlbumDetail';

var proxify = require('proxify-url');

class AlbumList extends Component {
    state = { albums: [] };

    componentWillMount() {

        //let proxyUrl = proxify("https://www.goodreads.com/review/list/36189301.xml?key=qY1rPUxjLx33WZDq6OkvEQ&v=2&per_page=200&shelf=read", { inputFormat: 'xml' });
        let proxyUrl = "https://api.themoviedb.org/4/account/57984952c3a368052f002968/tv/rated?page=1&sort_by=vote_average.desc";
        var headers = {
            "authorization": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5OWMyNjMwNmJlM2QxY2UwNTA5MGYyNDUwZmY5MGM2ZSIsInN1YiI6IjU3OTg0OTUyYzNhMzY4MDUyZjAwMjk2OCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.5GRbUI72s9w3JvlegvBx8N52lq4lcDSvZzYZsig5V2c"
        }
        axios.get(proxyUrl, { params: { format: "json" }, headers: headers })
            .then(
            response =>
                this.setState({ albums: response.data.results }));
    }

    renderAlbums() {
        return this.state.albums.map(album =>
            <AlbumDetail key={album.original_name} album={album} />
        );
    }

    render() {
        console.log(this.state);
        return (
            <ScrollView>
                {this.renderAlbums()}
            </ScrollView>
        );
    }
}

export default AlbumList;
