import React from 'react';
import { Text, View, Image, Linking } from 'react-native';
import Card from './Card';
import CardSection from './CardSection';
import Button from './Button';

const TvDetail = ({ album }) => {
    const { original_name, poster_path, link, vote_average } = album;
    const account_rating = album.account_rating.value;
    //const { artist, thumbnail_image } = album.author;
    const artist = "GRRM";
    const thumbnail_image = "https://api.themoviedb.org/4/account/57984952c3a368052f002968/tv/rated?page=1&sort_by=vote_average.desc";
    const {
    thumbnailStyle,
        headerContentStyle,
        thumbnailContainerStyle,
        headerTextStyle,
        imageStyle
  } = styles;

    function renderGenres(boxData) {
        const ids = boxData.genre_ids;
        const genres = [{ "id": 28, "name": "Action" }, { "id": 12, "name": "Adventure" }, { "id": 16, "name": "Animation" }, { "id": 35, "name": "Comedy" }, { "id": 80, "name": "Crime" }, { "id": 99, "name": "Documentary" }, { "id": 18, "name": "Drama" }, { "id": 10751, "name": "Family" }, { "id": 14, "name": "Fantasy" }, { "id": 36, "name": "History" }, { "id": 27, "name": "Horror" }, { "id": 10402, "name": "Music" }, { "id": 9648, "name": "Mystery" }, { "id": 10749, "name": "Romance" }, { "id": 878, "name": "Science Fiction" }, { "id": 10770, "name": "TV Movie" }, { "id": 53, "name": "Thriller" }, { "id": 10752, "name": "War" }, { "id": 37, "name": "Western" }];
        var genreTextArr = [];
        ids.map(function (i) {
            var item = genres.filter(function (e) {
                return e.id == i
            });
            item.length > 0 ? genreTextArr.push(item[0].name) : "";
        });
        // if (this.props.comments["tv:" + boxData.id].indexOf("dnf") > -1) {
        //     genreTextArr.push("DNF");
        // }
        return genreTextArr.join(", ");
    }

    return (
        <Card>
            <CardSection>
                <View style={thumbnailContainerStyle}>
                    <Image
                        style={imageStyle}
                        source={{ uri: "https://image.tmdb.org/t/p/w300_and_h450_bestv2" + poster_path }}
                    />
                </View>
                <View style={headerContentStyle}>
                    <Text style={headerTextStyle}>{original_name}</Text>
                    <Text>{renderGenres(album)}</Text>
                    {<Text>{vote_average}(Show rating)</Text>}
                    {<Text>{account_rating}(My rating)</Text>}
                </View>
            </CardSection>

            {/* <CardSection>
                <Image
                    style={imageStyle}
                    source={{ uri: "https://image.tmdb.org/t/p/w300_and_h450_bestv2" + poster_path }}
                />
            </CardSection> */}
        </Card>
    );
};

const styles = {
    headerContentStyle: {
        flexDirection: 'column',
        justifyContent: 'space-around'
    },
    headerTextStyle: {
        fontSize: 18
    },
    thumbnailStyle: {
        height: 50,
        width: 50
    },
    thumbnailContainerStyle: {
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 10,
        marginRight: 10
    },
    imageStyle: {
        height: 170,
        justifyContent: 'center',
        alignItems: 'center',
        // flex: 1,
        width: 120
    }
};

export default TvDetail;
